(function () {
    if (window.ymPrompt) return;
    window.ymPrompt = {
        version: '1.0',
        pubDate: '2012-11-13',
        apply: function (o, c, d) {
            if (d) ymPrompt.apply(o, d);
            if (o && c && typeof c == 'object') for (var p in c) o[p] = c[p];
            return o
        },
        eventList: []
    };
    var initFn = ['getPage', 'resizeWin', 'doHandler', 'close', 'setDefaultCfg', 'show'],
        _initFn = {},
        t;
    while (t = initFn.shift()) ymPrompt[t] = eval('0,function(){_initFn.' + t + '=arguments}');
    var useIframe = /MSIE (\d)\./.test(navigator.userAgent) && parseInt(RegExp.$1) < 7;
    var $ = function (id) {
            return document.getElementById(id)
        };
    var $height = function (obj) {
            return parseInt(obj.style.height) || obj.offsetHeight
        };
    var addEvent = (function () {
            return new Function('env', 'fn', 'obj', ['obj=obj||document;', window.attachEvent ? "obj.attachEvent('on'+env,fn)" : 'obj.addEventListener(env,fn,false)', ';ymPrompt.eventList.push([env,fn,obj])'].join(''))
        })();
    var detachEvent = (function () {
            return new Function('env', 'fn', 'obj', ['obj=obj||document;', window.attachEvent ? "obj.detachEvent('on'+env,fn)" : 'obj.removeEventListener(env,fn,false)'].join(''))
        })();
    var setStyle = function (el, n, v) {
            if (!el) return;
            if (typeof n == 'object') {
                for (var i in n) setStyle(el, i, n[i]);
                return
            }
            if (el instanceof Array || /htmlcollection|nodelist/i.test('' + el)) {
                for (var i = el.length - 1; i >= 0; i--) setStyle(el[i], n, v);
                return
            }
            el.style[n] = v
        };
    var btnIndex = 0,
        btnCache, seed = 0;
    var defaultBtn = function () {
            return {
                OK: [curCfg.okTxt, 'ok'],
                CANCEL: [curCfg.cancelTxt, 'cancel']
            }
        };
    var mkBtn = function (txt, sign, autoClose, id) {
            if (!txt) return;
            if (txt instanceof Array) {
                var item, t = [];
                while (txt.length)(item = txt.shift()) && t[t.push(mkBtn.apply(null, defaultBtn()[item] || item)) - 1] || t.pop();
                return t
            }
            id = id || 'ymPrompt_btn_' + seed++;
            autoClose = typeof autoClose == 'undefined' ? 'undefined' : !! autoClose;
            return {
                id: id,
                html: "<input type='button' id='" + id + "' onclick='ymPrompt.doHandler(\"" + sign + "\"," + autoClose + ")' style='cursor:pointer' class='btnStyle handler' value='" + txt + "' />"
            }
        };
    var joinBtn = function (btn) {
            if (!btn) return btnCache = '';
            if (!(btn instanceof Array)) btn = [btn];
            if (!btn.length) return btnCache = '';
            btnCache = btn.concat();
            var html = [];
            while (btn.length) html.push(btn.shift().html);
            return html.join('&nbsp;&nbsp;')
        };
    var dftCfg = {
            titleBar: true,
            fixPosition: true,
            dragOut: true,
            autoClose: true,
            showMask: true,
            maskAlphaColor: '#000',
            maskAlpha: 0.1,
            title: '提示',
            message: '内容',
            width: 300,
            height: 185,
            winPos: 'c',
            iframe: false,
            btn: null,
            closeTxt: '关闭',
            okTxt: ' 确 定 ',
            cancelTxt: ' 取 消 ',
            icoCls: '',
            handler: function () {}
        },
        curCfg = {};
        (function () {
            if (!document.body || typeof document.body != 'object') return addEvent('load', arguments.callee, window);
            var rootEl = document.compatMode == 'CSS1Compat' ? document.documentElement : document.body;
            var getScrollLeft = function () {
                return document.documentElement.scrollLeft == 0 ? document.body.scrollLeft : document.documentElement.scrollLeft
            };
            var getScrollTop = function () {
                return document.documentElement.scrollTop == 0 ? document.body.scrollTop : document.documentElement.scrollTop
            };
            var saveWinInfo = function () {
                ymPrompt.apply(dragVar, {
                    offX: ym_win.offsetLeft - getScrollLeft(),
                    offY: ym_win.offsetTop - getScrollTop()
                })
            };
            var maskStyle = 'position:absolute;top:0;left:0;display:none;text-align:center';
            var div = document.createElement('div');
            div.innerHTML = ["<div id='maskLevel' style=\'" + maskStyle + ';z-index:10000;\'></div>', useIframe ? ("<iframe id='maskIframe' style='" + maskStyle + ";z-index:9999;filter:alpha(opacity=0);opacity:0'></iframe>") : '', "<div id='ym-window' style='position:absolute;z-index:199990;display:none'>", useIframe ? "<iframe style='width:100%;height:100%;position:absolute;top:0;left:0;z-index:-1'></iframe>" : '', "<div class='ym-tl' id='ym-tl'><div class='ym-tr'><div class='ym-tc' style='cursor:move;'><div class='ym-header-text'></div><div class='ym-header-tools'></div></div></div></div>", "<div class='ym-ml' id='ym-ml'><div class='ym-mr'><div class='ym-mc'><div class='ym-body'></div></div></div></div>", "<div class='ym-ml' id='ym-btnl'><div class='ym-mr'><div class='ym-btn'></div></div></div>", "<div class='ym-bl' id='ym-bl'><div class='ym-br'><div class='ym-bc'></div></div></div>", "</div>"].join('');
            document.body.appendChild(div),
            div = null;
            var dragVar = {};
            var maskLevel = $('maskLevel');
            var maskIframe = $('maskIframe');
            var ym_win = $('ym-window');
            var ym_headbox = $('ym-tl');
            var ym_head = ym_headbox.firstChild.firstChild;
            var ym_hText = ym_head.firstChild;
            var ym_hTool = ym_hText.nextSibling;
            var ym_body = $('ym-ml').firstChild.firstChild.firstChild;
            var ym_btn = $('ym-btnl');
            var ym_btnContent = ym_btn.firstChild.firstChild;
            var ym_bottom = $('ym-bl');
            var mEvent = function (e) {
                e = e || window.event;
                var sLeft = dragVar.offX + (e.x || e.pageX);
                var sTop = dragVar.offY + (e.y || e.pageY);
                if (!curCfg.dragOut) {
                    var sl = getScrollLeft(),
                        st = getScrollTop();
                    sLeft = Math.min(Math.max(sLeft, sl), rootEl.clientWidth - ym_win.offsetWidth + sl);
                    sTop = Math.min(Math.max(sTop, st), rootEl.clientHeight - ym_win.offsetHeight + st)
                }
                try {
                    setStyle(ym_win, {
                        left: sLeft + "px",
                        top: sTop + "px"
                    })
                } catch (e) {}
            };
            var uEvent = function () {
                var bindEl = ym_head.releaseCapture && ym_head;
                detachEvent("mousemove", mEvent, bindEl);
                detachEvent("mouseup", uEvent, bindEl);
                saveWinInfo();
                bindEl && (detachEvent("losecapture", uEvent, bindEl), bindEl.releaseCapture())
            };
            addEvent('mousedown', function (e) {
                e = e || window.event;
                ymPrompt.apply(dragVar, {
                    offX: ym_win.offsetLeft - (e.x || e.pageX),
                    offY: ym_win.offsetTop - (e.y || e.pageY)
                });
                var bindEl = ym_head.setCapture && ym_head;
                addEvent("mousemove", mEvent, bindEl);
                addEvent("mouseup", uEvent, bindEl);
                bindEl && (addEvent("losecapture", uEvent, bindEl), bindEl.setCapture())
            }, ym_head);
            var keydownEvent = function (e) {
                var e = e || event;
                if (e.keyCode == 27) destroy();
                if (btnCache) {
                    var l = btnCache.length,
                        nofocus;
                    document.activeElement.id != btnCache[btnIndex].id && (nofocus = true);
                    if (e.keyCode == 9 || e.keyCode == 39) nofocus && (btnIndex = -1),
                    $(btnCache[++btnIndex == l ? (--btnIndex) : btnIndex].id).focus();
                    if (e.keyCode == 37) nofocus && (btnIndex = l),
                    $(btnCache[--btnIndex < 0 ? (++btnIndex) : btnIndex].id).focus();
                    if (e.keyCode == 13) return true
                }
                if ((e.keyCode > 110 && e.keyCode < 123) || e.keyCode == 9 || e.keyCode == 13) {
                    try {
                        e.returnValue = !(e.cancelBubble = true);
                        e.keyCode = 0
                    } catch (ex) {
                        try {
                            e.stopPropagation();
                            e.preventDefault()
                        } catch (e) {}
                    }
                }
            };
            var scrollEvent = function () {
                setStyle(ym_win, {
                    left: (dragVar.offX + getScrollLeft()) + 'px',
                    top: (dragVar.offY + getScrollTop()) + 'px'
                })
            };
            maskLevel.oncontextmenu = ym_win.onselectstart = ym_win.oncontextmenu = function () {
                return false
            };
            var _resizeMask = function () {
                setStyle([maskLevel, maskIframe], {
                    width: rootEl.scrollWidth + 'px',
                    height: rootEl.scrollHeight + 'px',
                    display: ''
                })
            };
            var resizeMask = function () {
                setStyle([maskLevel, maskIframe], 'display', 'none');
                !+'\v1' ? setTimeout(_resizeMask, 0) : _resizeMask()
            };
            var maskVisible = function (visible) {
                if (!curCfg.showMask) return;
                setStyle([maskLevel, maskIframe], 'display', 'none');
                (visible === false ? detachEvent : addEvent)("resize", resizeMask, window);
                if (visible === false) return;
                setStyle(maskLevel, {
                    background: curCfg.maskAlphaColor,
                    filter: 'alpha(opacity=' + (curCfg.maskAlpha * 100) + ')',
                    opacity: curCfg.maskAlpha
                });
                resizeMask()
            };
            var getPos = function (f) {
                var pos = [rootEl.clientWidth - ym_win.offsetWidth, rootEl.clientHeight - ym_win.offsetHeight, getScrollLeft(), getScrollTop()];
                var arr = f.replace(/\{(\d)\}/g, function (s, s1) {
                    return pos[s1]
                }).split(',');
                return [eval(arr[0]), eval(arr[1])]
            };
            var posMap = {
                c: '{0}/2+{2},{1}/2+{3}',
                l: '{2},{1}/2+{3}',
                r: '{0}+{2},{1}/2+{3}',
                t: '{0}/2+{2},{3}',
                b: '{0}/2,{1}+{3}',
                lt: '{2},{3}',
                lb: '{2},{1}+{3}',
                rb: '{0}+{2},{1}+{3}',
                rt: '{0}+{2},{3}'
            };
            var SetWinSize = function (w, h) {
                if (!ym_win || ym_win.style.display == 'none') return;
                curCfg.height = parseInt(h) || dftCfg.height;
                curCfg.width = parseInt(w) || dftCfg.width;
                setStyle(ym_win, {
                    left: 0,
                    top: 0,
                    width: curCfg.width + 'px',
                    height: curCfg.height + 'px'
                });
                var pos = posMap[curCfg.winPos];
                pos = pos ? getPos(pos) : curCfg.winPos;
                if (!(pos instanceof Array)) pos = getPos(posMap['c']);
                setStyle(ym_win, {
                    top: pos[1] + 'px',
                    left: pos[0] + 'px'
                });
                saveWinInfo();
                setStyle(ym_body, 'height', curCfg.height - $height(ym_headbox) - $height(ym_btn) - $height(ym_bottom) + 'px')
            };
            var _obj = [];
            var winVisible = function (visible) {
                var fn = visible === false ? detachEvent : addEvent;
                if (curCfg.fixPosition) fn("scroll", scrollEvent, window);
                fn("keydown", keydownEvent);
                if (visible === false) {
                    setStyle(ym_win, 'display', 'none');
                    setStyle(_obj, 'visibility', 'visible');
                    _obj = [];
                    return
                }
                for (var o = document.getElementsByTagName('object'), i = o.length - 1; i > -1; i--) o[i].style.visibility != 'hidden' && _obj.push(o[i]) && (o[i].style.visibility = 'hidden');
                setStyle([ym_hText, ym_hTool], 'display', curCfg.titleBar ? '' : 'none');
                ym_head.className = 'ym-tc' + (curCfg.titleBar ? '' : ' ym-ttc');
                ym_hText.innerHTML = curCfg.title;
                ym_hTool.innerHTML = "<div class='ymPrompt_close' title='" + curCfg.closeTxt + "' onclick='ymPrompt.doHandler(\"close\")'>&nbsp;</div>";
                ym_body.innerHTML = !curCfg.iframe ? ('<div class="ym-content">' + curCfg.message + '</div>') : "<iframe width='100%' height='100%' border='0' frameborder='0' src='" + curCfg.message + "'></iframe>";
                ym_body.className = "ym-body " + curCfg.icoCls;
                setStyle(ym_btn, 'display', (ym_btnContent.innerHTML = joinBtn(mkBtn(curCfg.btn))) ? '' : 'none');
                setStyle(ym_win, 'display', '');
                if (!curCfg.titleBar) {
                    setStyle(ym_headbox, 'margin-top', '0px');
                    setStyle($('ym-ml'), 'padding-left', '0px');
                    setStyle($('ym-ml').firstChild, 'padding-right', '0px');
                    setStyle(ym_bottom, 'height', '0px')
                }
                SetWinSize(curCfg.width, curCfg.height);
                btnCache && $(btnCache[btnIndex = 0].id).focus()
            };
            var init = function () {
                maskVisible();
                winVisible()
            };
            var destroy = function () {
                maskVisible(false);
                winVisible(false)
            };
            ymPrompt.apply(ymPrompt, {
                close: destroy,
                getPage: function () {
                    return ym_body.firstChild.tagName.toLowerCase() == 'iframe' ? ym_body.firstChild : null
                },
                show: function (args, fargs) {
                    var a = Array.prototype.slice.call(args, 0),
                        o = {};
                    if (typeof a[0] != 'object') {
                            var cfg = ['message', 'width', 'height', 'title', 'handler', 'maskAlphaColor', 'maskAlpha', 'iframe', 'icoCls', 'btn', 'autoClose', 'fixPosition', 'dragOut', 'titleBar', 'showMask', 'winPos'];
                            for (var i = 0, l = a.length; i < l; i++) if (a[i]) o[cfg[i]] = a[i]
                        } else {
                            o = a[0]
                        }
                    ymPrompt.apply(curCfg, ymPrompt.apply({}, o, fargs), ymPrompt.setDefaultCfg());
                    for (var i in curCfg) curCfg[i] = curCfg[i] != null ? curCfg[i] : ymPrompt.cfg[i];
                    init()
                },
                doHandler: function (sign, autoClose) {
                    if (typeof autoClose == 'undefined' ? curCfg.autoClose : autoClose) destroy();
                    eval(curCfg.handler)(sign)
                },
                resizeWin: SetWinSize,
                setDefaultCfg: function (cfg) {
                    return ymPrompt.cfg = ymPrompt.apply({}, cfg, ymPrompt.apply({}, ymPrompt.cfg, dftCfg))
                }
            });
            ymPrompt.setDefaultCfg();
            for (var i in _initFn) ymPrompt[i].apply(null, _initFn[i]);
            addEvent('unload', function () {
                while (ymPrompt.eventList.length) detachEvent.apply(null, ymPrompt.eventList.shift())
            }, window)
        })()
})();
ymPrompt.apply(ymPrompt, {
    alert: function () {
        ymPrompt.show(arguments, {
            icoCls: 'ymPrompt_alert',
            btn: ['OK']
        })
    },
    succeedInfo: function () {
        ymPrompt.show(arguments, {
            icoCls: 'ymPrompt_succeed',
            btn: ['OK']
        })
    },
    errorInfo: function () {
        ymPrompt.show(arguments, {
            icoCls: 'ymPrompt_error',
            btn: ['OK']
        })
    },
    confirmInfo: function () {
        ymPrompt.show(arguments, {
            icoCls: 'ymPrompt_confirm',
            btn: ['OK', 'CANCEL']
        })
    },
    win: function () {
        ymPrompt.show(arguments)
    }
});

var common = {
    util: {
        stringFormat: function () {
            var a = arguments[0];
            if (1 < arguments.length) if (2 == arguments.length && "object" == typeof arguments[1]) {
                var b = arguments[1],
                    d;
                for (d in b) if (void 0 != b[d]) var c = new RegExp("({" + d + "})", "g"),
                    a = a.replace(c, b[d])
            } else for (b = 1; b < arguments.length; b++) void 0 != arguments[b] && (c = new RegExp("({[" + (b - 1) + "]})", "g"), a = a.replace(c, arguments[b]));
            return a
        },
        subString: function (a, b, d) {
            for (var c = 0, f = "", e = /[^\x00-\xff]/g, h = "", g = a.replace(e, "**").length, k = 0; k < g; k++) {
                h = a.charAt(k).toString();
                null != h.match(e) ? c += 2 : c++;
                if (c > b) break;
                f += h
            }
            d && g > b && (f += "...");
            return f
        },
        getUrlKey_Value: function (a, b) {
            if (a) {
                var d = a.replace("?", "").split("&"),
                    c, f, e;
                if (isNaN(b)) {
                        for (var h = 0, g = d.length; h < g; h++) if (c = d[h].split("="), 1 < c.length && (f = c[0], c = c[1], f == b)) {
                            e = c;
                            break
                        }
                        return e
                    }
                c = d[b].split("=");
                return 1 < c.length ? c[1] : c[0]
            }
        },
        showPrompt: function (a, b, d, c) {
            if (b) {
                var f = 15 * b.length;
                d = Math.round("" == d || isNaN(d) ? 1E3 : 1E3 * d);
                var e = $('<div style="display:none"><div class="tooltip"><div class="tooltipMsg" style="width:' + f + 'px">' + b + '</div><div class="tips_sanjiao" style="top:28px;left:27px"></div></div></div>').css({
                    position: "absolute",
                    display: "hidden",
                    "text-align": "center",
                    "z-index": "999999"
                });
                c && e.addClass(c);
                e.appendTo("body");
                e.offset({
                    top: $(a).offset().top - e.height() - 16,
                    left: $(a).offset().left + Math.round($(a).width() / 2 - e.width() / 2) - 35
                });
                e.animate({
                    top: $(a).offset().top - e.height() - 40,
                    opacity: "toggle"
                }, "normal");
                e.delay(d || 1E3);
                e.animate({
                    top: $(a).offset().top - e.height() - 56,
                    opacity: "opacity"
                }, "fast", function () {
                    e.remove()
                })
            }
        },
        getUA: function () {
            var a = window,
                b = navigator,
                d = b.userAgent.toLowerCase(),
                c = b.platform.toLowerCase(),
                f = c ? /win/.test(c) : /win/.test(d),
                c = c ? /mac/.test(c) : /mac/.test(d),
                d = /webkit/.test(d) ? parseFloat(d.replace(/^.*webkit\/(\d+(\.\d+)?).*$/, "$1")) : !1,
                e = !+"\v1",
                h = [0, 0, 0],
                g = null;
            if ("undefined" != typeof b.plugins && "object" == typeof b.plugins["Shockwave Flash"])!(g = b.plugins["Shockwave Flash"].description) || "undefined" != typeof b.mimeTypes && b.mimeTypes["application/x-shockwave-flash"] && !b.mimeTypes["application/x-shockwave-flash"].enabledPlugin || (plugin = !0, e = !1, g = g.replace(/^.*\s+(\S+\s+\S+$)/, "$1"), h[0] = parseInt(g.replace(/^(.*)\..*$/, "$1"), 10), h[1] = parseInt(g.replace(/^.*\.(.*)\s.*$/, "$1"), 10), h[2] = /[a-zA-Z]/.test(g) ? parseInt(g.replace(/^.*[a-zA-Z]+(.*)$/, "$1"), 10) : 0);
            else if ("undefined" != typeof a.ActiveXObject) try {
                    var k = new ActiveXObject("ShockwaveFlash.ShockwaveFlash");
                    k && (g = k.GetVariable("$version")) && (e = !0, g = g.split(" ")[1].split(","), h = [parseInt(g[0], 10), parseInt(g[1], 10), parseInt(g[2], 10)])
                } catch (l) {}
            return {
                    pv: h,
                    wk: d,
                    ie: e,
                    win: f,
                    mac: c
                }
        },
        hasPlayerVersion: function (a) {
            var b = this.getUA().pv;
            a = a.split(".");
            a[0] = parseInt(a[0], 10);
            a[1] = parseInt(a[1], 10) || 0;
            a[2] = parseInt(a[2], 10) || 0;
            return b[0] > a[0] || b[0] == a[0] && b[1] > a[1] || b[0] == a[0] && b[1] == a[1] && b[2] >= a[2] ? !0 : !1
        }
    },
    cookie: {
        settings: {
            cookieExpires: 864E6,
            domain: ".migu.cn"
        },
        getExpDate: function (a, b, d) {
            var c = new Date;
            if ("number" == typeof a && "number" == typeof b && "number" == typeof b) return c.setDate(c.getDate() + parseInt(a)),
            c.setHours(c.getHours() + parseInt(b)),
            c.setMinutes(c.getMinutes() + parseInt(d)),
            c.toGMTString()
        },
        getCookie: function (a) {
            a += "=";
            for (var b = a.length, d = document.cookie.length, c = 0; c < d;) {
                var f = c + b;
                if (document.cookie.substring(c, f) == a) return this.getCookieVal(f);
                c = document.cookie.indexOf(" ", c) + 1;
                if (0 == c) break
            }
            return ""
        },
        getCookieVal: function (a) {
            var b = document.cookie.indexOf(";", a); - 1 == b && (b = document.cookie.length);
            return unescape(document.cookie.substring(a, b))
        },
        getCookies: function () {
            _Cookie = [];
            if (-1 != document.cookie.indexOf(";")) {
                var a, b, d = document.cookie.split("; "),
                    c = d.length;
                for (i = 0; i < c; i++) a = d[i].split("="),
                b = a[0],
                _value = a[1],
                _coo = [{
                        name: b,
                        value: _value
                    }],
                _Cookie.push(_coo)
            }
            return _Cookie
        },
        setCookie: function (a, b, d, c, f, e) {
            document.cookie = a + "=" + escape(b) + (d ? "; expires=" + d : "") + (c ? "; path=" + c : "") + (f ? "; domain=" + f : "") + (e ? "; secure" : "")
        },
        deleteCookie: function (a, b, d) {
            if (this.getCookie(a)) {
                var c = new Date;
                c.setTime(c.getTime() - 100);
                this.setCookie(a, "", c.toGMTString(), b, d)
            }
        },
        clearCookie: function () {
            cookies = this.getCookies();
            for (i = 0; i < cookies.length; i++) this.deleteCookie(cookies[i].name)
        }
    },
    web_log: {
        url_arg: "",
        url_obj: {},
        addURLArg: function (a) {
            var b = common.web_log;
            $.extend(b.url_obj, a);
            b.url_arg = $.param(b.url_obj);
            $("a[href]").each(function () {
                var d = $.trim($(this).attr("href"));
                if (/^[A-Za-z]+:\/\/[A-Za-z0-9-_]+\.[A-Za-z0-9-_%&?/.=]+$/.test(d) && !$(this).hasClass("noLogLink")) for (var c in a) $(this).attr("href", b.changeURLArg($(this).attr("href"), c, a[c]))
            })
        },
        changeURLArg: function (a, b, d) {
            d = b + "=" + d;
            return a.match(b + "=([^&]*)") ? a = a.replace(eval("/(" + b + "=)([^&]*)/gi"), d) : a.match("[?]") ? a + "&" + d : a + "?" + d
        }
    },
    isLogin: function () {
        if (Boolean(this.isLogin)) {
            var a = common.project._getAjaxResult({
                url: common._getUrl.isLogin,
                async: !1
            });
            return this._isLogin = a.isLogin
        }
        return this._isLogin
    },
    getUserInfo: function () {
        var a = common.project;
        if (this.userInfo) return this.userInfo;
        var b = common.cookie.getCookie("USER_SESSION_ID");
        return b && (a = a._getAjaxResult({
            url: common._getUrl.getUserInfo,
            data: {
                sessionId: b
            },
            async: !1
        })) && a.userInfo ? this.userInfo = a.userInfo : null
    },
    getUserId: function () {
        if (this.userInfo && this.userInfo.uid) return this.userInfo.uid;
        var a = this.getUserInfo();
        return a && a.uid ? a.uid : null
    },
    getMemLevel: function (a) {
        return (a = this.getUserInfo()) && a.memLevel ? a.memLevel : null
    },
    showLoginWin: function (a) {
        ymPrompt.win({
            message: '<div class="overlay_login"><div class="title_wrap clearfix"><h1 class="title_login fl"></h1><i class="ib icon_close fr"></i></div><p class="fontsh clearfix pl20 pt20 pb10"><i class="ib icon_tip fl mr20"></i><em class="fl mt10">\u60a8\u8fd8\u672a\u767b\u5f55\uff0c\u662f\u5426\u7acb\u523b\u767b\u5f55\uff1f</em></p><div class="pt20 tc fb"><a class="ib btn login_btn mr10" href="javascript:void(0);">\u767b\u5f55</a><a class="ib btn cancel_btn" href="javascript:void(0);">\u53d6\u6d88</a></div></div>',
            width: 300,
            height: 170,
            titleBar: !1
        });
        $(".overlay_login").find(".icon_close,.cancel_btn").unbind("click").bind("click", function () {
            ymPrompt.close();
            return !1
        });
        $(".overlay_login").find(".login_btn").unbind("click").bind("click", function () {
            //var b = common._getUrl.loginUrl + "" + (a || window.top.location.href); - 1 != b.indexOf("/#") && (b = b.replace("/#", "/pl_"));
            //window.top.location.href = b;
            $('#a_login').click();
            return !1
        })
    },
    showFlashUpateWin: function () {
        ymPrompt.win({
            message: '<div class="overlay_login"><div class="title_wrap clearfix"><i class="ib icon_close fr"></i></div><p class="fontsh clearfix mt10 pl20 pt20 pb10"><i class="ib icon_tip fl mr10"></i><em class="fl" style="width:200px;">\u60a8\u7684flash\u4e0d\u652f\u6301\u54aa\u5495\u97f3\u4e50\u64ad\u653e\uff0c\u8bf7\u66f4\u65b0flash\u3002</em></p><div class="pt20 tc fb"><a class="ib btn login_btn mr10" href="http://get.adobe.com/cn/flashplayer/">\u66f4\u65b0</a><a class="ib btn cancel_btn" href="javascript:void(0);">\u53d6\u6d88</a></div></div>',
            width: 300,
            height: 170,
            titleBar: !1
        });
        $(".overlay_login").find(".icon_close,.cancel_btn").unbind("click").bind("click", function () {
            ymPrompt.close();
            return !1
        });
        $(".overlay_login").find(".login_btn").unbind("click").bind("click", function () {
            window.top.open(" http://get.adobe.com/cn/flashplayer/");
            return !1
        })
    },
    collectItem: function (a, b, d, c, f, e) {
        var h, g, k;
        a && (h = common.util.getUrlKey_Value(a, "loc"), g = common.util.getUrlKey_Value(a, "locno"), k = common.util.getUrlKey_Value(a, "cid"));
        a = common._getUrl.addCollect;
        "true" == common.isLogin() ? $.ajax({
            url: a,
            data: {
                itemid: b,
                ulike: d || 1,
                loc: h ? h : "",
                locno: g ? g : "",
                cid: k ? k : ""
            },
            dataType: "json",
            type: "post",
            success: function (a) {
                "000000" != a.code || "1" != a.state && "2" != a.state ? f.apply(e || f.caller, [a]) : c.apply(e || c.caller, [a])
            },
            error: function (a) {
                f.apply(e || f.caller, [a])
            }
        }) : common.showLoginWin()
    },
    initHotMan: function () {
        common.getHotman(function (a) {
            a ? ($("#h_chosen_person").empty(), $("#h_chosen_person").append(a)) : common.util.showPrompt($(this), "\u5220\u9664\u5931\u8d25")
        })
    },
    getHotman: function (a) {
        $.ajax({
            type: "GET",
            async: !1,
            url: common._getUrl.getHotman,
            cache: !1,
            dataType: "html",
            success: function (b) {
                a instanceof Function && a(b)
            }
        })
    },
    getItemInfo: function (a, b) {
        return common.project._getAjaxResult({
            url: common._getUrl.getItemInfo,
            data: {
                type: b,
                itemid: a
            },
            async: !1
        })
    },
    changeCid: function () {
        var a = this,
            b = window.top.location.href,
            d = b.match("cid=([^&]*)"),
            c = d && d[1];
        c || (b = b.split("#/"), 1 < b.length && (b = b[1].split("/"), c = b[4]));
        c && "001002A" != c && $("a").each(function () {
                var b = $.trim($(this).attr("href")).split("#/"),
                    d = $(this).attr("data_log"),
                    h = "cid=" + c;
                d && d.match("cid=([^&]*)") ? (d = d.replace(/(cid=)([^&]*)/gi, h), $(this).attr("data_log", d)) : d && $(this).attr("data_log", d + "&" + h);
                1 < b.length ? (d = b[1], d = d.split("/"), 4 <= d.length && (d[4] = c), d = d.join("/"), b = b[0] + "#/" + d) : b = a.web_log.changeURLArg(b[0], "cid", c);
                /^[A-Za-z]+:\/\/[A-Za-z0-9-_]+\.[A-Za-z0-9-_%&?/.=#]+$/.test(b) && !$(this).hasClass("noLogLink") && $(this).attr("href", b)
            })
    }
};


common._getUrl = {
    //判断是否登录
    isLogin: 'http://music.migu.cn/webfront/user/isLogin.do',
    //获得用户信息
    getUserInfo: 'http://music.migu.cn/webfront/user/getLoginUser.do',
    //登录地址
    loginUrl: "http://music.migu.cn/webfront/UcLogin/login.do?t=login&returnUrl=",
    //添加收藏
    addCollect: 'http://music.migu.cn/webfront/collect/addcollect.do',
    //定购页面地址
    toOrder: 'http://music.migu.cn/webfront/order/showOrder.do',
    //人气达人
    getHotman: 'http://music.migu.cn/webfront/ualbum/getHotman.do',
    //分享获得的详细信息
    getItemInfo: 'http://music.migu.cn/webfront/collect/getShare.do'
};
common.project = {
    MobileRegex: /^1(3|8)[0-9]{9}$|^1(45|47|50|51|52|53|55|56|57|58|59|70|76|77|78)[0-9]{8}$/,
    //移动手机号正则
    _getAjaxResult: function () {
        var result;
        var args = arguments[0];
        var url = args.url,
            data = args.data,
            ty = args.type || 'GET',
            async = (args.async != null && args.async != undefined) ? args.async : true,
            cache = (args.cache != null && args.cache != undefined) ? args.cache : false;
        var callFunc = args.callFunc,
            errorFunc = args.errorFunc;
        $.ajax({
                type: ty,
                url: url,
                data: data,
                async: async,
                cache: cache,
                success: function (data) {
                    result = data;
                    if ($.isFunction(callFunc)) {
                        callFunc.apply(window, [data]);
                    }
                },
                error: function (data) {
                    result = data;
                    if ($.isFunction(errorFunc)) {
                        errorFunc.apply(window, [data]);
                    }
                },
                dataType: 'json',
                timeout: 6000
            });

        return result;
    },
    initCommonIcon: function () {
        var _self = common;
        var urls = common._getUrl;
        var util = common.util;
        //播放
        $('.icon_uplay,.icon_c_play').die('click').live('click', function (event) {
            event.stopPropagation();
            var p = $(this).parent('.icon_tools');
            var itemid = p.attr('itemid');
            var type = p.attr('type') || 'song';
            var w = window.top;
            var isColor = $(this).hasClass('icon_c_play') ? true : false;
            w.Player.toPlayList(itemid, type, false, $(this), false, isColor);
            //util.showPrompt($(this),'播放成功');
            /*
             if(!w.FlashACR.getProperty("lock")){
             w.Player.viewPlayer(true);
             setTimeout(function(){
             w.Player.viewPlayer(false);
             },1200);
             }
             */
        });
        //下载和彩铃
        $('.icon_udown,.icon_ucolor').die('click').live('click', function (event) {
            event.stopPropagation();
            var url = urls.toOrder;
            var p = $(this).parent('.icon_tools');
            var itemid = p.attr('itemid');
            //var li = $(this).parents("li");
            var logArg = p.attr('data_log') || $(this).attr('data_log') || '';
            (logArg && common.web_log.url_arg) ? (logArg += '&' + common.web_log.url_arg) : (logArg += common.web_log.url_arg);
            if (itemid) {
                url += '?songId=' + itemid + '&type=';
                if ($(this).hasClass('icon_udown')) {
                    url += 'down';
                } else {
                    url += 'color';
                }
                var view = $(this).attr('view') || 'self';
                url += '&view=' + view;

                if ((navigator.userAgent.indexOf('MSIE') >= 0) && (navigator.userAgent.indexOf('Opera') < 0)) {
                    var openUrl = url + ((logArg.length > 0) ? '&' + logArg : '');
                    var $aa = $('<a>').appendTo($('body'));
                    $aa.html('showOrder');
                    $aa.attr('href', openUrl);
                    $aa.attr('target', '_blank');
                    $aa.get(0).click();
                } else {
                    window.open(url + ((logArg.length > 0) ? '&' + logArg : ''), '_blank');
                }
            } else {
                util.showPrompt($(this), '未获得歌曲id');
            }
        });
        //分享
        $('.icon_ushare').die('click').live('click', function (event) {
            event.stopPropagation();
            var p = $(this).parent('.icon_tools');
            var itemid = p.attr('itemid');
            var type = p.attr('type') || 'song';
            $('#bdshare').attr({
                itemid: itemid,
                stype: type
            });
            shareSong($(this), itemid, type);
        });
        //收藏
        $('.icon_ulike').die('click').live('click', function (event) {
            event.stopPropagation();
            //登录后才能进行收藏操作
            if (common.isLogin() == 'false') {
                common.showLoginWin();
                return;
            }
            var p = $(this).parent('.icon_tools');
            var itemid = p.attr('itemid');
            var type = p.attr('type') || 'song';
            var likeType = {
                song: 1,
                singer: 2,
                album: 3,
                ualbum: 4
            };
            var target = $(this);
            //var li = $(this).parents("li");
            var logArg = p.attr('data_log') || $(this).attr('data_log') || '';
            (logArg && common.web_log.url_arg) ? (logArg += '&' + common.web_log.url_arg) : (logArg += common.web_log.url_arg);
            _self.collectItem(logArg, itemid, likeType[type], function (data) {
                if (target) {
                    target.addClass('like_focus');
                    util.showPrompt(target, data.state == '1' ? '收藏成功' : '你已收藏');
                } else {
                    $(this).addClass('like_focus');
                    util.showPrompt($(this), data.state == '1' ? '收藏成功' : '你已收藏');
                }

            }, function (data) {
                if (target) {
                    util.showPrompt(target, '收藏失败');
                } else {
                    util.showPrompt($(this), '收藏失败');
                }
            }, target);
        });
        //分享浮层


        function shareSong(target, itemid, stype) {
            var tarObj = target;
            var self = this;
            var div = $('#bdshare');
            if (div.length == 0) {
                $('body').append('<div id="bdshare" class="com_share_wrap_white sprt" style="left: 82px; top: 300px; position:absolute"><a href="javascript:void(0);" target="_blank" class="sprt com_share_sina" title="新浪微博" type="sina">新浪微博</a><a href="javascript:void(0);" class="sprt com_share_wx" title="微信" type="wx">微信</a><a href="javascript:void(0);" target="_blank" class="sprt com_share_qzone" title="腾讯空间" type="qzone">腾讯空间</a><a href="javascript:void(0);" target="_blank" class="sprt com_share_qq" title="腾讯QQ" type="qqWin">腾讯QQ</a><a href="javascript:void(0);" target="_blank" class="sprt com_share_tx" title="腾讯微博" type="qq">腾讯微博</a><a href="javascript:void(0);" target="_blank" class="sprt com_share_rr" title="人人网" type="renren">人人网</a><a href="javascript:void(0);" target="_blank" class="sprt com_share_fx" title="飞信" type="feixin">飞信</a></div>');
                div = $('#bdshare');
                div.hover(function () {
                    if (self._shareTimer) {
                        clearTimeout(self._shareTimer)
                    }
                    $(this).show()
                }, function () {
                    if (self._shareTimer) {
                        clearTimeout(self._shareTimer)
                    }
                    $(this).hide()
                });
                div.find('a').click(function (event) {
                    event.preventDefault();
                    var id = $('#bdshare').attr('itemid');
                    var type = $('#bdshare').attr('stype');
                    var shareType = $(this).attr('type');
                    var info = common.getItemInfo(id, type);
                    if (info.code == "000000" && info.msg) {
                        shareOpenf(shareType, info.msg.itemname, '', id, type, info.msg.itempic);
                    }
                });
            }
            stype = stype || 'song';
            div.attr({
                'stype': stype,
                'itemid': itemid || ''
            }).show();
            div.offset({
                top: $(tarObj).offset().top - div.height(),
                left: $(tarObj).offset().left + Math.round($(tarObj).width() / 2 - div.width()) + 15
            });
            if (this._shareTimer) {
                clearTimeout(this._shareTimer)
            }
            this._shareTimer = setTimeout(function () {
                div.hide()
            }, 2000);
        };
    }
};
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  分享模块 
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/******************************** ************************************************************************************************************/

function shareOpenf(shareType, sname, surl, sid, stype, spic, stext) {
    var shareArray = [
        ['sina', 'http://v.t.sina.com.cn/share/share.php?url='],
        ['qq', 'http://v.t.qq.com/share/share.php?url='],
        ['renren', 'http://widget.renren.com/dialog/share?resourceUrl='],
        ['feixin', 'http://i.feixin.10086.cn/apps/share/share?url='],
        ['qzone', 'http://sns.qzone.qq.com/cgi-bin/qzshare/cgi_qzshare_onekey?url='],
        ['qqWin', 'http://connect.qq.com/widget/shareqq/index.html?url=']
    ];
    var keyArray = [
        ['sina', '2432910183'],
        ['qq', '100396384'],
        ['renren', 'fc9cdc590cc3407699a22dfb795aacab'],
        ['feixin', '12ef2776be48e90d39b81bc9995e41e9'],
        ['qzone', ''],
        ['qqWin', '']
    ];

    var s = sname || '',
        u = surl || window.top.location.href,
        stype = stype || 'song',
        sid = sid || '',
        pic = spic || ((stype == 'zhuanti' || stype == 'raffle') ? 'http://img01.12530.com/res/images/zt/zhuantisharedefault.jpg' : 'http://img01.12530.com/res/images/default.jpg_RsT_110x110.jpg');
    var f = '',
        k = '';
    var text = '',
        t2 = "和我一起来听听吧!";
    //若是微信，打开二维码弹窗
    if (shareType == 'wx') {
            if ($.inArray(stype, ['song', 'album', 'ualbum']) != -1) {
                var _ss = (stype == 'song' ? 'single' : stype);
                u = common.util.stringFormat('http://music.migu.cn/music-mobile/{0}_share.html?{1}id={2}&loc=weixin&cid=0010010', _ss, stype, sid);
                ymPrompt.win({
                    message: 'http://music.migu.cn/184_2277.html?code=' + encodeURIComponent(u),
                    iframe: true,
                    width: 502,
                    height: 422,
                    titleBar: false
                }); //2277,1145
            } else {
                ymPrompt.alert('启奏陛下，此类型资源暂不支持微信分享');
            }
        } else {
            //渠道标示和渠道id
            var pei = {
                sina: ['weibo', '001002H'],
                qzone: ['Qzone', '0010060'],
                qqWin: ['QQ', '0010062'],
                qq: ['txweibo', '0010061'],
                renren: ['renren', '0010011'],
                feixin: ['feixin', '001091C']
            };
            switch (stype) {
            case 'song':
                text = "听《" + s + "》";
                break;
            case 'singer':
                text = "听" + s + "的音乐";
                break;
            case 'album':
                text = "听专辑《" + s + "》";
                break;
            case 'ualbum':
                text = "听音乐精选集《" + s + "》";
                break;
            case 'LP':
                text = "听咪咕唱片《" + s + "》";
                break;
            case 'info':
                text = "看娱乐资讯《" + s + "》";
                t2 = "和我一起观注明星最新动态吧!";
                break;
            case 'party':
                text = "参加《" + s + "》活动";
                t2 = "和我一起参加活动吧!";
                break;
            case 'MV':
                text = "点播《" + s + "》";
                t2 = "和我一起观看吧!";
                break;
            case 'zhuanti':
                text = "浏览专题《" + s + "》";
                t2 = "和我一起看看吧!";
                break;
            case 'raffle':
                text = "浏览专题《" + s + "》，还可以免费拿奖~更多精彩，";
                break;
            case 'cailing':
                text = "制作了一个DIY彩铃";
                t2 = "赶快来看看吧!";
                break;
            default:
                text = "听《" + s + "》";
                break;
            }
            if ($.inArray(stype, ['song', 'singer', 'album', 'ualbum']) != -1) {
                u = common.util.stringFormat('http://music.migu.cn/#/{0}/{1}/{2}/1/{3}', stype, sid, pei[shareType][0], pei[shareType][1]);
            } else if ($.inArray(stype, ['MV', 'zhuanti']) != -1) {
                u = common.web_log.changeURLArg(u, 'loc', pei[shareType][0]);
                u = common.web_log.changeURLArg(u, 'cid', pei[shareType][1]);
            }
            var t = '我正在#中国移动咪咕音乐网#' + text + (stype == 'raffle' ? '就在music.migu.cn' : ',快上music.migu.cn,' + t2) + '(分享自@咪咕和你听音乐) ';
            if (stype == 'summary') t = stext;
            for (var i = 0; i < shareArray.length; i++) {
                if (shareArray[i][0] == shareType) {
                    f = shareArray[i][1];
                    k = keyArray[i][1];
                }
            }
            if (shareType == 'sina' && stype == 'song') {
                pic = ""; //新浪分享歌曲不传图片
            }
            var p = [encodeURIComponent(u), '&appkey=', k];
            if (shareType == 'renren') {
                //分享地址为srcUrl
                p.push('&srcUrl=' + encodeURIComponent(u));
            }
            if (pic != "") {
                if (shareType != 'qzone' && shareType != 'qqWin') {
                    p.push('&pic=' + encodeURIComponent(pic));
                } else {
                    p.push('&pics=' + encodeURIComponent(pic));
                }
            }
            if (shareType == 'feixin') {
                var fx_title = common.util.stringFormat("{0}_{1}", (stype == 'singer' ? s + '的主打音乐' : s), (jQuery.inArray(stype, ['song', 'ualbum', 'LP']) != -1 ? '点击试听' : '查看详情')); //待定
                p.push('&title=' + encodeURIComponent(fx_title) + '&comment=');
            } else {
                p.push('&title=');
            }
            p.push(encodeURIComponent(t));
            p = p.join('');

            function a() {
                if (!window.open([f, p].join(''), shareType, '')) {
                    u.href = [f, p].join('');
                }
            }
            if (/Firefox/.test(navigator.userAgent)) {
                setTimeout(a, 0);
            } else {
                a();
            };

        }


};
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  页头
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/******************************** ************************************************************************************************************/
var new_header = {
    _indexURl: {
        user_space: 'http://music.migu.cn/#/webfront/myring/ringManage.do',
        logoutURL: 'http://music.migu.cn/webfront/UcLogin/loggout.do',
        //退出
        loginURL: 'http://music.migu.cn/webfront/UcLogin/login.do?t=login&returnUrl=',
        //登录
        registerUrl: 'http://music.migu.cn/webfront/UcLogin/login.do?t=register&returnUrl=',
        //注册
        memberPage_new: 'http://music.migu.cn/#/ringmonth/184_114.html',
        //会员权益页面
        getUser_money: 'http://music.migu.cn/webfront/UcLogin/msn.do',
        //用户积分
        likeSongURL: 'http://music.migu.cn/webfront/UcLogin/getRecmom.do',
        //猜你喜欢
        caiyunURL: 'http://music.migu.cn/webfront/richlifeApp/login.do',
        //彩云
        getOverLay: 'http://music.migu.cn/rank/184_1304.html',
        //特会浮层-非特会
        getOverLay_th: 'http://music.migu.cn/rank/184_1301.html' //特会浮层
    },
    initLogin: function () {
        var html = "";
        var p = common;
        var info = p.getUserInfo();
        //会员html;
        var indexURLs = this._indexURl;
        var _url = indexURLs.user_space;
        if (info) {
            var ucname = info.username;
            var mobile = info.mobile;
            var imgUrl = info.imageUrl.replace(/\"/g, "");
            _url += '?uid=' + info.uid;
            var level = info.memLevel;
            var stype = "",
                html = [];
            var tex1 = "（成为咪咕特级会员）",
                tex2 = "";
            if (level == 1) {
                    stype = "top_ph";
                    tex2 = "普通会员"
                } else if (level == 2) {
                    stype = "top_gh";
                    tex2 = "高级会员";
                } else if (level == 3) {
                    stype = "top_th";
                    tex1 = "（会员专区）";
                    tex2 = "咪咕特级会员";
                } else {
                    tex2 = "非会员";
                }
            html.push('<li><span><a href="' + _url + '">' + ucname + '</a></span><span style="margin:0px;display:none;" id="migu_header_moneyDiv">(余额：<a style="color:#dd137b;text-decoration:underline;float:none;" id="migu_header_fee" target="_blank" href="http://www.sc.10086.cn/my/" class="noLogLink">￥0</a>&nbsp;&nbsp;&nbsp;积分：<a style="color:#dd137b;text-decoration:underline;float:none;" id="migu_header_score" target="_blank" href="http://www.sc.10086.cn/my/" class="noLogLink">0分</a>)</span><span class="line">&nbsp;&nbsp;| </span></li>');
            html.push('<li id="member_li" class="hy_li" style="position:relative;"><em class="sprt sprt_icon_migu" style="width:25px;"></em><span>' + tex2 + '</span><a href="javascript:;" id="a_usercenter" >' + tex1 + '</a><span class="line">| </span>');
            //浮层
            html.push('<div class="top_vip_info" style="display:none;"></div><em class="sanjiao sprt sprt_icon_arrow_up"></em></li>');

            html.push('<li  class="mr10"><a href="javascript:;" id="a_logout" class="mr20" >退出</a></li>');

            $("#web_login").html(html.join(''));
            $("#a_logout").attr("href", indexURLs.logoutURL);

        } else {
            html = '<li><em class="sprt sprt_icon_user"></em><a href="javascript:;" id="a_login" >登录</a><span class="line">| </span><a href="javascript:void(0);" id="a_register" target="_blank">注册</a></li><li><em class="sprt sprt_icon_memmber"></em><a href="javascript:;" id="a_usercenter" >会员</a></li>';
            $("#web_login").html(html);
            var topWin = window.top || window.parent;
            var returnUrl = indexURLs.registerUrl + '' + topWin.location.href;
            if (returnUrl.indexOf("/#") != -1) returnUrl = returnUrl.replace("/#", "/pl_");
            $("#a_register").attr("href", returnUrl + "&loc=P9Z1Y1L1N1&locno=1");
        }
        $('#a_usercenter').attr("href", indexURLs.memberPage_new + "?loc=P9Z1Y1L1N1&locno=2");
        //移动通行证
        this.creatMMPass(info);
        //余额和积分
        this.getUserMoney(mobile);
        this._getOverLay(info && info.memLevel);
    },
    _getOverLay: function (level) {
        var index_urls = new_header._indexURl;
        var url = (level == 3) ? index_urls.getOverLay_th : index_urls.getOverLay;
        $.ajax({
            type: "GET",
            url: url,
            dataType: 'html',
            success: function (resp) {
                if (resp && $.trim(resp) != '') {
                    var info = $("#member_li").find(".top_vip_info");
                    info.append(resp);
                    $("#member_li").hover(function () {
                        $(this).find(".top_vip_info,.sanjiao").show();
                    }, function () {
                        $(this).find(".top_vip_info,.sanjiao").hide();
                    });
                }
            }
        });
    },
    creatMMPass: function (info) {
        return; //icerain下线  2015-08-18
        var html = [],
            html1 = [],
            html2 = [];
        var p = common;
        var usession = p.cookie.getCookie('USER_SESSION_IDM');
        if (usession && usession != "" && usession != "\"\"" && info) {

                var m = info.mobile || info.email;

                html.push('<ul class="logined fr header_pass"><li class="pass_id"><a href="javascript:void(0)">你好，' + m + '</a><em class="sprt sprt_icon_arrow_down"></em>');
                html.push('<div class="passLayout passLayout2 hide_pass" style="display:none;"><dl><dt>咪咕账号：</dt>');
                html.push('<dd><a href="" target="_blank" class="rightlink" title="进入咪咕认证中心">进入咪咕认证中心</a><span title="' + (info.username || '') + '" class="leftlink">' + (info.username || '') + '</span></dd></dl>');
                html.push('<dl><dt>手机号码：</dt><dd>' + (info.mobile ? info.mobile : '<a href="" target="_blank" class="rightlink" title="去绑定">去绑定</a>未绑定') + '</dd></dl>');
                html.push('<dl><dt>邮箱：</dt><dd>' + (info.email ? info.email : '<a href="" target="_blank" class="rightlink" title="去绑定">去绑定</a>未绑定') + '</dd></dl>');
                html.push('<dl><dt>账号管理：</dt><dd><a href="" target="_blank" class="modbtn" title="修改密码">修改密码</a><a href="" target="_blank" class="modbtn" title="修改密保">设置密保</a></dd></dl>');

                html.push('<ul><li><a href="http://music.migu.cn/" target="_blank" class="link_music" title="咪咕音乐"><span></span>咪咕音乐</a></li>');
                html.push('<li><a href="http://user.migu.cn/passport/goto.action?target=game-www" target="_blank" class="link_game" title="和游戏"><span></span>和游戏</a></li>');
                html.push('<li><a href="http://user.migu.cn/passport/goto.action?target=video-www" target="_blank" class="link_video" title="和视频"><span></span>和视频</a></li>');
                html.push('<li><a href="http://user.migu.cn/passport/goto.action?target=dm_www" target="_blank" class="link_manga" title="和动漫"><span></span>和动漫</a></li>');
                html.push('<li class="last"><a href="http://user.migu.cn/passport/goto.action?target=cmreadwww" target="_blank" class="link_read" title="和阅读"><span></span>和阅读</a></li></ul>');

                html.push('</div></li></ul>');
            } else {
                var lurl = 'service=' + location.href;
                html.push('<ul class="logined fr header_pass" style="display:none;"><li><em class="sprt sprt_icon_new ml20"></em><a href="javascript:void(0)">移动通行证</a>');
                html.push('<div class="passLayout hide_pass" style="display:none;"><em class="sanjiao_pass sprt sprt_icon_arrow_up"></em><div class="passBox"><span class="sprt sprt_btn_close close" title="关闭">关闭</span>');
                html.push('<div id="idmm_login_out" style="display: block;"><p style="color:#888">有移动通行证后，可以方便您使用更多业务，省去记住多套账号密码的麻烦！</p><div class="passBtn"><a href="http://user.migu.cn/register/index.action?' + lurl + '" class="regPass" target="_self">立即注册通行证</a><a href="http://user.migu.cn/login/index.action?' + lurl + '" class="logPass" target="_self">登录通行证</a></div>');
                html.push('</div></div></li></ul>');
            }
        $('.head_top').prepend(html.join(''));
        //shijian
        $(".header_pass").hover(function () {
                $(".hide_pass").show();
                $('.pass_id').addClass('pass_id_hover');
            }, function () {
                $(".hide_pass").hide();
                $('.pass_id').removeClass('pass_id_hover');
            });
        $(".hide_pass .close").click(function () {
                $(".hide_pass").hide();
            });
    },
    getUserMoney: function (mobile) {
        if (mobile && mobile != 'null') {
            mobile = $.trim(mobile);
            var url = this._indexURl.getUser_money;
            $.getJSON(url + "?msn=" + mobile + "&jsonpcallback=?", function (data) {
                if (data && data.returnCode == '000000') {
                    $('#migu_header_fee').text('￥' + (data.fee || 0));
                    $('#migu_header_score').text((data.score || 0) + '分');
                    $('#migu_header_moneyDiv').show();
                } else {
                    $('#migu_header_moneyDiv').hide();
                }
            });
        }
    },
    initBusiness: function (index, subIndex) {
        //选择当前tab标签
        index = index || 0,
        subIndex = subIndex || 0;
        $('.nav> ul:not(.sub_nav)').children('li').removeClass('current');
        var current = $('.nav> ul:not(.sub_nav)').children('li:eq(' + index + ')');
        current.addClass('current');
        var ul = current.children('ul').show();
        ul.find('li>a:eq(' + subIndex + ')').addClass('current');
        //铃音库
        $('.ring_manage').live('click', function (even) {
            var _rex = $(this).attr('data_log');
            if (common.isLogin() == 'true') {
                window.open(new_header._indexURl.user_space + '?' + (_rex || 'loc=P9Z1Y1L2N3&locno=0'), '_self');
            } else {
                common.showLoginWin(new_header._indexURl.user_space + '?' + (_rex || 'loc=P9Z1Y1L2N3&locno=0'));
            }
        });
        //开通咪咕会员
        $('.sprt_btn_ktmghy').live('click', function (even) {
            window.open('http://music.migu.cn/#/ringmonth/184_97.html?loc=P9Z1Y1L2N2&locno=1', '_self');
        });
        $('#a_login,#index_login').live('click', function (even) {
            document.cookie = 'loginReturnUrl=' + window.top.location.href + ';path=/;domain=migu.cn';
            //window.top.location.href = new_header._indexURl.loginURL+ '' + window.top.location.href;
            var returnUrl = new_header._indexURl.loginURL + '' + window.top.location.href;
            if (returnUrl.indexOf("/#") != -1) returnUrl = returnUrl.replace("/#", "/pl_"); //登录页面需转换#
            window.top.location.href = returnUrl;
        });
        //二级菜单显示
        $(".nav>ul:not(.sub_nav)>li").hover(function () {
            $(".nav .current ul").hide();
            $(this).addClass("active");
            $(this).children("ul").stop(true, true).show();
        }, function () {
            $(this).removeClass("active");
            $(this).find("ul").stop(true, true).hide();
            $(".nav .current ul").show();
        });
        //加入收藏
        $('.addFav_index').click(function () {
            try {
                window.external.addFavorite(window.location.href, '中国移动咪咕音乐');
            }
            catch (e) {
                try {
                    window.sidebar.addPanel('中国移动咪咕音乐', window.location.href, "");
                }
                catch (e) {
                    alert("抱歉，您当前使用的浏览器暂不支持一键收藏！\n\n请使用Ctrl+D直接添加，或使用浏览器菜单手动收藏！");
                }
            }
        });
        //设为首页
        $('.setHome_index').click(function () {
            var obj = $(this)[0];
            try {
                obj.style.behavior = 'url(#default#homepage)';
                obj.setHomePage(window.location.href);
            } catch (e) {
                if (window.netscape) {
                    try {
                        netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");
                    } catch (e) {
                        alert("抱歉，您当前使用的浏览器暂不支持一键添加！\n\n请通过浏览器菜单，手动将网站设为首页！");
                    }
                } else {
                    alert("抱歉，您当前使用的浏览器暂不支持一键添加！\n\n请通过浏览器菜单，手动将网站设为首页！");
                }
            }
        });
        //彩云
        $('#index_caiyun').click(function () {
            var info = common.getUserInfo();
            if (info && info.memLevel && info.memLevel == 3) {
                //特级会员
                window.open(new_header._indexURl.caiyunURL, '_blank');
            } else {
                window.open('http://caiyun.feixin.10086.cn/Mcloud/proxy/sso.jsp', '_blank');
            }
        });
        //换一批
        //$('#ylogin').
        $('.change_songs').live('click', function (event) {
            var divList = $('#changeSongList').find('div');
            for (var i = 0; i < divList.length; i++) {
                var tmpObj = divList[i];
                if ($(tmpObj).is(":visible")) {
                    if (i < (divList.length - 1)) {
                        var nextObj = $(divList[i]).next();
                        nextObj.show();
                        $(tmpObj).hide();
                        break;
                    } else {
                        $(divList[0]).show();
                        $(tmpObj).hide();
                        break;
                    }

                }
            }
        });
    },
    init: function (index, curIndex) {
        this.initLogin(); //头部
        this.initBusiness(index, curIndex); //页面功能
        //搜索
        var s1 = new migu_search('searchBar1');
        s1.autoComplete();
        var s2 = new migu_search('searchBar2');
        s2.autoComplete(true);
        //this.showLikeSong(index);
        //通用按钮
        common.project.initCommonIcon();
    },
    showLikeSong: function (tv) {
        var t = tv;
        if (common.isLogin() == "true") {
            var info = common.getUserInfo();
            if (info && info.mobile != '') {
                new_header.getLikeSong(t, function (data) {
                    if (data) {
                        var $rec = (t == 0) ? $(".m_tabs_item").eq(1) : $(".g_cnxh");
                        $rec.empty();
                        $rec.append(data);
                    }
                });
            } else {
                if (t != 1) {
                    var html = '<span class="fl"><em class="fl"></em>' + info.username + ',咪咕猜你喜欢听：</span><div class="fr"><a href="javascript:;" class="change_songs" style="margin-top: 8px;display:none;">换一组 </a></div>';
                    var $res = $(".m_tabs_item").eq(1).find(".tools");
                    $res.empty();
                    $res.append(html);
                }
            }
        }
    },
    getLikeSong: function (t, callback) {
        $.ajax({
            type: "GET",
            async: false,
            url: new_header._indexURl.likeSongURL,
            cache: false,
            dataType: 'html',
            data: {
                t: t
            },
            success: function (resp) {
                if (callback instanceof Function) {
                    callback(resp);
                }
            }
        });
    }
};

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  搜索
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/******************************** ************************************************************************************************************/

function migu_search(searchBarId, opt) {
    this.bar = $('#' + searchBarId);
    this.text = this.bar.find(':text');
    this.button = this.bar.find(':button');
    var option = {
        url: "http://music.migu.cn/webfront/search/sug.do",
        goToURL: "http://music.migu.cn/#/webfront/search/uss.do",
        delay: 800,
        defaultValue: '请输入关键字',
        defaultvalueCss: {
            'color': 'gray'
        }
    };
    this.options = $.extend(option, opt || {});
    this.isSelect = false;
    this.KEYS = {
        UP: 38,
        DOWN: 40,
        DEL: 46,
        TAB: 9,
        RETURN: 13,
        ESC: 27,
        BACKSPACE: 8
    };
    this._index = -1;
    this.cache = {};
};
migu_search.prototype.getSelecter = function (type) {
    var selecters = { // 选择器数组，方便修改
        'bar': this.bar,
        "text": this.text,
        "button": this.button
    };
    return selecters[type];
};
migu_search.prototype.setDefaultValue = function (v) {
    if (v && $.trim(v) != '') {
        this.options.defaultValue = v;
        $(this.getSelecter("text")).val(v).css(this.options.defaultvalueCss);
    }
};
migu_search.prototype.searchFilter = function () {
    /*
    var re = re = /[~@%&`\<>\/\\]/i; //[ ] { } （ ） $ * # ? ， 。 . ! + = ' ' " " 
    var oField = $(this.getSelecter("text"));
    if (re.test(oField.val())) {
        ymPrompt.alert("请您不要输入特殊字符和sql关键字");
        oField.attr("value", "");
        oField.focus();
        return false;
    }*/
	return true;
};
migu_search.prototype.initTextEvent = function () {
    var self = this;
    $(this.getSelecter("text")).keyup(function (e) {
        self.searchFilter();
    }).blur(function () {
        if (!self.isSelect) {
            $(self.getSelecter("bar")).removeClass("searchBarFocus");
            self.table.hide();
        }
        var dv = self.options.defaultValue;
        if ($.trim($(this).val()) == '') {
            $(this).val(dv);
        }
        $(this).css(self.options.defaultvalueCss);
    }).focus(function () {
        $(this).css('color', 'black');
        var dv = self.options.defaultValue;
        if ($(this).val() == dv) {
            $(this).val('');
        }
        $(self.getSelecter("bar")).addClass("searchBarFocus");
    });
	//icerain 获取焦点后,立即联想
	$(this.getSelecter("text")).focus(function(){
		if(this.value.length >0){
		   self.table.show();
		}
	});
    $(this.getSelecter("text")).bind(($.browser.opera ? "keypress" : $.browser.mozilla ? 'keyup' : "keydown"), function (event) {
        var key = self.KEYS;
        switch (event.keyCode) {
        case key.UP:
            event.preventDefault();
            if (self.table.is(':visible')) {
                self.tableSelectLiPrev();
            }
            break;
        case key.DOWN:
            event.preventDefault();
            if (self.table.is(':visible')) {
                self.tableSelectLiNext();
            }
            break;
        case key.TAB:
        case key.RETURN:
            if (self.table.is(':visible')) {
                event.preventDefault();
                var li = $(self.getSelecter("bar")).find('li.cur');
                if (li.length != 0) {
                    li.trigger('click');
                } else {
                    $(self.getSelecter("button")).trigger('click');
                }
            } else {
                self.timeout = clearTimeout(self.timeout);
                $(self.getSelecter("button")).trigger('click');
            }
            $(this).blur();
            return false;
            break;
        case key.ESC:
            self.table.hide();
            break;
        default:
            self._index = -1;
            self.timeout = clearTimeout(self.timeout);
            self.timeout = setTimeout(function () {
                var word = $(self.getSelecter("text")).val();
                if (word && $.trim(word) != '') {
                    var data = self.cache[word];
                    if (data) {
                        self.success(word, data);
                    } else {
                        self.request();
                    }
                } else {
                    self.table.hide();
                }
            }, self.options.delay);
            break;
        }
    });
};
migu_search.prototype.tableSelectLiPrev = function () {
    var lis = $(this.getSelecter("bar")).find('li');
    if (this._index > 0 && this._index < lis.length) {
        lis.removeClass('cur');
        this._index--;
        lis.eq(this._index).addClass('cur');
    }
    return false;
};
migu_search.prototype.tableSelectLiNext = function () {
    var lis = $(this.getSelecter("bar")).find('li');
    if (this._index < lis.length - 1) {
        lis.removeClass('cur');
        this._index++;
        lis.eq(this._index).addClass('cur');
    }
    return false;
};
migu_search.prototype.initLiEvent = function () {
    var self = this;
    var lis = $(self.getSelecter("bar")).find('li');
    lis.last().css("border", "none");
    lis.hover(function () {
        $(this).toggleClass("cur");
    });
    lis.click(function () {
        var val = $(this).attr('data');
        //$(self.getSelecter("text")).val(val);
        self.table.hide();
        var type = $(this).parents('.searchRes_item').attr('type');
        var url = common.util.stringFormat('http://music.migu.cn/#/{0}/{1}/P7Z1Y1L3N1/1/001002C', type, val);
        window.open(url, '_self');
        //$(self.getSelecter("button")).attr('gotoType',type).trigger('click');
        return false;
    }).mousedown(function () {
        self.isSelect = true;
    }).mouseup(function () {
        self.isSelect = false;
    });
};
migu_search.prototype.initSelectBtn = function () {
    var self = this;
    $(self.getSelecter("button")).unbind('click').bind('click', function () {
        var word = $(self.getSelecter("text")).val();
        var t = $(this).attr('gotoType') || 'all';
        t = 'all';
        if (word && $.trim(word) != '' && word != '请输入关键字') {
            var url = self.options.goToURL + "?keyword=" + word + "&keytype=" + t + "&pagesize=20&pagenum=1";
            url = encodeURI(url);
            window.open(url, '_self');
        }
        return false;
    });
};
migu_search.prototype.highlight = function (value, term) {
    if (value) {
        return value.replace(new RegExp("(?![^&;]+;)(?!<[^<>]*)(" + term.replace(/([\^\$\(\)\[\]\{\}\*\.\+\?\|\\])/gi, "\\$1") + ")(?![^<>]*>)(?![^&;]+;)", "gi"), "<em>$1</em>");
    } else {
        return value;
    }
};
migu_search.prototype.initTableHTML = function () {
    var tableHTML = '<div class="searchRes" style="display: none;"><div class="searchRes_item" type="song"></div><div class="searchRes_item" style="background:#fafafa;" type="singer"></div><div class="searchRes_item" type="album"></div> <div class="clearfix"></div></div>';
    $(this.getSelecter("bar")).append(tableHTML);
    this.table = $(this.getSelecter("bar")).find('.searchRes');
};
//type:song,singer,album; data:[{keyword:''}]
migu_search.prototype.initTrData = function (data, type, word) {
    var tr = this.table.find('.searchRes_item[type="' + type + '"]');
    var name = (type == 'song') ? '歌曲' : (type == 'singer' ? '歌手' : '专辑');
    var titleHTMl = common.util.stringFormat('<div class="tit"><i class="searchResIcon icon_search_{0}"></i><h6>{1}</h6></div>', type, name);
    var data_td = '';
    if (data) {
        var data_li = '',
            item;
        var len1 = (type == 'song') ? data.length : ((data.length > 3) ? 3 : data.length);
        for (var i = 0, len = len1; i < len; i++) {
                item = data[i];
                data_li += common.util.stringFormat('<li data="{0}"><a href="javascript:void(0);"><span>{1}</span>{2}</a></li>', item.id, this.highlight(common.util.subString(item.name, 26, false), word), (type != 'singer' && item.singer != undefined) ? (' - ' + this.highlight(item.singer, word) || '暂无歌手') : '');
            }
        data_td = common.util.stringFormat('<ul>{0}</ul>', data_li);
    }
    tr.empty().append(titleHTMl + data_td);
    if (!data || data.length == 0) {
        tr.hide();
    } else {
        tr.show();
    }
};
//data:{song:[],singer:[],album:[]}
migu_search.prototype.showSelectTable = function (data, word) {
    var table = this.table;
    if (data) {
        this.initTrData(data.song || [], 'song', word);
        this.initTrData(data.singer || [], 'singer', word);
        this.initTrData(data.album || [], 'album', word);
        this.initLiEvent();
        table.show();
    } else {
        table.hide();
    }
};
migu_search.prototype.autoComplete = function (noExpend) {
    if (!noExpend) {
        this.initTableHTML();
        this.initTextEvent();
    } else {

        var self = this;
        $(this.getSelecter("text")).keyup(function (e) {
            self.searchFilter();
        }).blur(function () {

            var dv = self.options.defaultValue;
            if ($.trim($(this).val()) == '') {
                $(this).val(dv);
            }
            $(this).css(self.options.defaultvalueCss);

        }).focus(function () {
            $(this).css('color', 'black');
            var dv = self.options.defaultValue;
            if ($(this).val() == dv) {
                $(this).val('');
            }
            $(self.getSelecter("bar")).addClass("searchBarFocus");
        });

        $(this.getSelecter("text")).bind(($.browser.opera ? "keypress" : $.browser.mozilla ? 'keyup' : "keydown"), function (event) {
            var key = self.KEYS;
            switch (event.keyCode) {
            case key.TAB:
            case key.RETURN:
                self.timeout = clearTimeout(self.timeout);
                $(self.getSelecter("button")).trigger('click');
                $(this).blur();
                return false;
                break;
            }
        });
    }

    this.initSelectBtn();
    var v = $(this.getSelecter("text")).val();
    if (v && $.trim(v) != '') {
        this.setDefaultValue(v);
    }
};

migu_search.prototype.request = function (type) {
    var self = this;
    var word = $(this.getSelecter("text")).val();
    type = type || 'all';

    $.ajax({
        url: self.options.url,
        data: {
            keyword: word
        },
        dataType: 'json',
        cache: false,
        success: function (data) {
            self.cache[word] = data;
            //migu_cache.add(word, data);
            self.success(word, data);
        }
    });
};
migu_search.prototype.success = function (word, data) {
    //var keys = data.returnValues;
    if (data) {
        this.showSelectTable(data, word);
    } else {
        this.table.hide();
    }
};

//统计代码插码
jQuery(document).ready(function ($) {
    //除去播放器页面都需插入
    if (!window.Player) {
        setTimeout(function () {
            var s = document.createElement('script');
            s.src = 'http://ua.hy.10086.cn/wtj/js/jsplug-in/ada.min.js?Z1uadIsU7ScavcIXJ2';
            document.body.appendChild(s);
        }, 1500);
    }
});
//国双统计
(function () {
    var s = document.createElement('script');
    s.type = 'text/javascript';
    s.async = true;
    s.src = (location.protocol == 'https:' ? 'https://ssl.' : 'http://static.') + 'gridsumdissector.com/js/Clients/GWD-002761-989A71/gs.js';
    var firstScript = document.getElementsByTagName('script')[0];
    firstScript.parentNode.insertBefore(s, firstScript);
})();


/**************** 门户游客日志统计 start *************************************************/

var cookie_id = getCookie("migu_cookie_id");
setMiguCookie(cookie_id);

// 设置咪咕音乐网站客户端cookie_id


function setMiguCookie(cookie_id) {
    var exp = new Date();
    exp.setTime(exp.getTime() + 7 * 24 * 60 * 60 * 1000);
    if (cookie_id == null || cookie_id.length < 38) {
        cookie_id = uuid() + '-n4' + new Date().getTime();
    }
    document.cookie = "migu_cookie_id=" + cookie_id + ";expires=" + exp.toGMTString() + ";path=/;domain=migu.cn";
}

// 设置咪咕音乐网站客户端cookie_id


function getCookie(name) {
    var arr, reg = new RegExp("(^| )" + name + "=([^;]*)(;|$)");
    if (arr = document.cookie.match(reg)) return unescape(arr[2]);
    else return null;
}

// 获得随机uuid值


function uuid() {
    var s = [];
    var hexDigits = "0123456789abcdef";
    for (var i = 0; i < 36; i++) {
        s[i] = hexDigits.substr(Math.floor(Math.random() * 0x10), 1);
    }
    s[14] = "4"; // bits 12-15 of the time_hi_and_version field to 0010
    s[19] = hexDigits.substr((s[19] & 0x3) | 0x8, 1); // bits 6-7 of the clock_seq_hi_and_reserved to 01
    s[8] = s[13] = s[18] = s[23] = "-";

    var uuid = s.join("");
    return uuid;
}

// 将新生成的cookie_id存入数据库


function insertMiguCookie(cookie_id) {
    //$.get('http://music.migu.cn/webfront/httpProxy/doRequest.do',
    $.get("http://localhost:8080/webfront/cookie/insertCookie.do", {
        cookie_id: cookie_id
    }, function (data, status) {});
}

/**************** 门户游客日志统计 end *************************************************/